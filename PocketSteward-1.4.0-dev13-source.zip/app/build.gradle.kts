val pocketStewardKeystorePath =
    providers.environmentVariable("POCKET_STEWARD_KEYSTORE_PATH").orNull
val pocketStewardKeystorePassword =
    providers.environmentVariable("POCKET_STEWARD_KEYSTORE_PASSWORD").orNull
val pocketStewardKeyAlias =
    providers.environmentVariable("POCKET_STEWARD_KEY_ALIAS").orNull
val pocketStewardKeyPassword =
    providers.environmentVariable("POCKET_STEWARD_KEY_PASSWORD").orNull

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.pocketsteward.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.pocketsteward.app"
        minSdk = 30
        targetSdk = 36
        versionCode = 53
        versionName = "1.4.0-dev13"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    val canonicalDevelopmentSigning = if (
        pocketStewardKeystorePath != null &&
        pocketStewardKeystorePassword != null &&
        pocketStewardKeyAlias != null &&
        pocketStewardKeyPassword != null
    ) {
        signingConfigs.create("pocketStewardDevelopment") {
            storeFile = file(pocketStewardKeystorePath)
            storePassword = pocketStewardKeystorePassword
            keyAlias = pocketStewardKeyAlias
            keyPassword = pocketStewardKeyPassword
        }
    } else {
        null
    }

    buildTypes {
        release {
            canonicalDevelopmentSigning?.let { signingConfig = it }

            // Real-device acceptance builds stay unminified so hardware tests
            // exercise the same code paths as the green debug/instrumentation
            // suite, and package only the canonical phone ABI.
            isMinifyEnabled = false
            isShrinkResources = false
            ndk {
                abiFilters += "arm64-v8a"
            }
        }
        debug {
            isDebuggable = true
            canonicalDevelopmentSigning?.let { signingConfig = it }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

ksp {
    arg("room.schemaLocation", "$projectDir/schemas")
    arg("room.generateKotlin", "true")
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.06.01")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.9.0")
    implementation("androidx.activity:activity-compose:1.10.0")

    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    implementation("androidx.navigation:navigation-compose:2.8.4")

    implementation("androidx.room:room-runtime:2.8.4")
    implementation("androidx.room:room-ktx:2.8.4")
    ksp("androidx.room:room-compiler:2.8.4")

    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("androidx.work:work-runtime-ktx:2.10.3")
    implementation("androidx.documentfile:documentfile:1.0.1")
    // Maintained EXIF reader. The platform android.media.ExifInterface has
    // format bugs fixed only in this library and lint flags it.
    implementation("androidx.exifinterface:exifinterface:1.4.1")
    implementation("org.apache.commons:commons-compress:1.28.0")

    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.9.0")

    // M10B: bundled Latin OCR keeps scanned-PDF support available without a
    // second user-visible model download ceremony.
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("com.google.mlkit:image-labeling:17.0.9")

    // M10B: Gemini Nano remains behind AgentModel; this dependency is the
    // Android implementation, not part of the planner/executor safety spine.
    implementation("com.google.mlkit:genai-prompt:1.0.0-beta4")
    ksp("com.google.mlkit:genai-schema-compiler:1.0.0-alpha1")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.9.0")
    testImplementation("app.cash.turbine:turbine:1.2.0")
    testImplementation("com.google.truth:truth:1.4.4")
    // Test-only: run Room migration SQL against a real SQLite database on the
    // JVM, and read the committed app/schemas/*.json files to compare the
    // migrated tables with what Room expects. Neither ships in the APK.
    testImplementation("org.xerial:sqlite-jdbc:3.46.1.3")
    implementation("com.google.code.gson:gson:2.11.0")

    androidTestImplementation("androidx.test.ext:junit:1.2.1")
    androidTestImplementation("androidx.room:room-testing:2.8.4")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.6.1")
    androidTestImplementation("androidx.compose.ui:ui-test-junit4")
    androidTestImplementation("com.google.truth:truth:1.4.4")
}
