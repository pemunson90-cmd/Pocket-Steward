package com.pocketsteward.app.filing

import com.pocketsteward.app.rules.ProjectKeyword
import com.pocketsteward.app.saved.CorrectionRule
import com.pocketsteward.app.saved.ProjectHierarchyStrategy
import java.util.Locale
import kotlin.math.abs

/**
 * Deterministic project/release resolver for inbox filing.
 *
 * The engine never emits an arbitrary absolute path from model text. It only
 * chooses among already-authorized homes or derives a single safe project
 * name under [storageRoot]. Path construction and mutation stay in the plan
 * adapter / validator layer.
 */
object InboxFilingEngine {
    private const val STRONG_SCORE = 82
    private const val PROBABLE_SCORE = 62
    private const val AMBIGUOUS_PROJECT_MARGIN = 15
    private const val COHORT_WINDOW_MS = 6L * 60L * 60L * 1000L
    private const val SUPPORTING_COHORT_WINDOW_MS = 45L * 60L * 1000L
    private val manuscriptRole = Regex("(^|[^a-z])(manuscript|novel|chapters?)([^a-z]|$)")
    private val draftRole = Regex("(^|[^a-z])(drafts?|revisions?)([^a-z]|$)")
    private val notesRole = Regex("(^|[^a-z])(notes?|research|outline)([^a-z]|$)")

    private val headingMarker = Regex("""(?i)\b(project|manuscript|drafts?|notes|outline)\b""")

    private val genericTokens = ProjectEvidenceTerms.generic

    fun resolve(
        artifacts: List<FilingArtifact>,
        persistedHomes: List<ProjectHomeCandidate>,
        discoveredHomes: List<ProjectHomeCandidate>,
        projectKeywords: List<ProjectKeyword>,
        correctionRules: List<CorrectionRule>,
        storageRoot: String,
        newProjectRoles: Map<String, String> = emptyMap(),
    ): InboxFilingResult {
        if (artifacts.isEmpty()) return InboxFilingResult(emptyList())

        val homes = (persistedHomes + discoveredHomes)
            .distinctBy { normalize(it.path) }
        val repeatedLabels = artifacts
            .mapNotNull { guessedProjectLabel(it.displayName) }
            .groupingBy { normalizeCompact(it) }
            .eachCount()

        val anchors = artifacts.map { artifact ->
            resolveAnchor(
                artifact = artifact,
                homes = homes,
                projectKeywords = projectKeywords,
                correctionRules = correctionRules,
                storageRoot = storageRoot,
                repeatedLabels = repeatedLabels,
            )
        }

        // Second pass: a file with real project evidence but no release can
        // inherit a nearby unique release from that same project. Time alone
        // is never enough to establish project membership.
        val releaseIndex = anchors.filter { it.projectName != null && it.release != null }
            .groupBy { normalizeCompact(requireNotNull(it.projectName)) }
            .mapValues { (_, decisions) -> decisions.groupBy { requireNotNull(it.release) }.mapValues { (_, group) -> TimedCohort(group) } }
        val releaseResolved = anchors.map { decision ->
            if (decision.artifact.isDirectory || decision.confidence == FilingConfidence.UNRESOLVED || decision.release != null || decision.projectName == null) {
                decision
            } else {
                val releases = releaseIndex[normalizeCompact(decision.projectName)].orEmpty()
                    .filterValues { it.countNear(eventTime(decision.artifact), COHORT_WINDOW_MS) > 0 }.keys.toList()
                if (releases.size == 1 && decision.evidence.any { it.kind != FilingEvidenceKind.COHORT }) {
                    val release = releases.single()
                    decision.copy(
                        release = release,
                        destinationDirectory = destinationFor(
                            requireNotNull(decision.projectHome),
                            release,
                            decision.artifact,
                        ),
                        confidence = if (decision.confidence == FilingConfidence.STRONG) FilingConfidence.STRONG else FilingConfidence.PROBABLE,
                        evidence = decision.evidence + FilingEvidence(
                            FilingEvidenceKind.COHORT,
                            "nearby artifact from the same project identifies release $release",
                            18,
                        ),
                    )
                } else {
                    decision
                }
            }
        }

        // A generic supporting asset may still be useful to show in review when
        // it arrived in the middle of one unambiguous, strongly identified
        // project/release burst. This never becomes a default-selected strong
        // match: temporal proximity alone only promotes it to PROBABLE.
        val supportingIndex = releaseResolved.filter { it.confidence == FilingConfidence.STRONG && it.projectHome != null }
            .groupBy { normalize(requireNotNull(it.projectHome).path) to it.release }
            .values.map { TimedCohort(it) }
        val resolved = releaseResolved.map { decision ->
            val categoryOnly = decision.confidence == FilingConfidence.PROBABLE && decision.evidence.all { it.kind in setOf(FilingEvidenceKind.IMAGE_CONTENT, FilingEvidenceKind.MEDIA_METADATA) }
            if ((!categoryOnly && decision.confidence != FilingConfidence.UNRESOLVED) || !isSupportingArtifact(decision.artifact)) {
                decision
            } else {
                val cohorts = supportingIndex.map { it to it.countNear(eventTime(decision.artifact), SUPPORTING_COHORT_WINDOW_MS) }
                    .filter { it.second > 0 }.sortedByDescending { it.second }
                val winner = cohorts.firstOrNull()
                val runnerUpSize = cohorts.getOrNull(1)?.second ?: 0
                if (winner != null && winner.second > runnerUpSize) {
                    val anchor = winner.first.representative
                    val home = requireNotNull(anchor.projectHome)
                    val release = anchor.release
                    decision.copy(
                        projectName = home.name,
                        projectHome = home,
                        release = release,
                        destinationDirectory = destinationFor(home, release, decision.artifact),
                        confidence = FilingConfidence.PROBABLE,
                        evidence = listOf(
                            FilingEvidence(
                                FilingEvidenceKind.COHORT,
                                "possible supporting file: arrived with strong ${home.name}${release?.let { " $it" }.orEmpty()} artifacts",
                                45,
                            ),
                        ),
                    )
                } else if (categoryOnly && cohorts.isNotEmpty()) {
                    decision.copy(projectName = null, projectHome = null, destinationDirectory = null, confidence = FilingConfidence.UNRESOLVED,
                        evidence = listOf(FilingEvidence(FilingEvidenceKind.PROJECT_AMBIGUITY, "Related project cohorts compete; keep this asset in Uncertain for review.", 80)))
                } else {
                    decision
                }
            }
        }

        return InboxFilingResult(resolved.map { decision ->
            val home = decision.projectHome
            if (decision.createsProjectHome && home?.hierarchy == ProjectHierarchyStrategy.PROJECT_ROLES && !decision.artifact.isDirectory) {
                val templated = home.copy(roleFolders = newProjectRoles)
                decision.copy(projectHome = templated, destinationDirectory = destinationFor(templated, decision.release, decision.artifact))
            } else decision
        })
    }

    /** Sorted per-cohort times replace repeated scans of the whole inbox. */
    private class TimedCohort(decisions: List<FilingDecision>) {
        val representative = decisions.first()
        private val times = decisions.mapNotNull { eventTime(it.artifact) }.sorted().toLongArray()
        fun countNear(time: Long?, window: Long): Int {
            if (time == null) return 0
            val low = if (time < Long.MIN_VALUE + window) Long.MIN_VALUE else time - window
            val high = if (time > Long.MAX_VALUE - window) Long.MAX_VALUE else time + window
            return boundary(high, inclusive = true) - boundary(low, inclusive = false)
        }
        private fun boundary(value: Long, inclusive: Boolean): Int {
            var low = 0
            var high = times.size
            while (low < high) {
                val mid = (low + high) ushr 1
                if (times[mid] < value || (inclusive && times[mid] == value)) low = mid + 1 else high = mid
            }
            return low
        }
    }

    private fun resolveAnchor(
        artifact: FilingArtifact,
        homes: List<ProjectHomeCandidate>,
        projectKeywords: List<ProjectKeyword>,
        correctionRules: List<CorrectionRule>,
        storageRoot: String,
        repeatedLabels: Map<String, Int>,
    ): FilingDecision {
        val imageTopic = if (!artifact.isDirectory && !storageRoot.startsWith("content://") &&
                artifact.extension.lowercase(Locale.ROOT) in setOf("png", "jpg", "jpeg", "webp", "gif", "heic")) {
                val words = artifact.displayName.lowercase(Locale.ROOT).split(Regex("[^a-z0-9]+")).toSet()
                val topics = listOf(
                    "Landscape" to setOf("landscape", "mountain", "mountains", "forest", "sunset", "scenery"),
                    "Portraits" to setOf("portrait", "portraits", "headshot"),
                    "Screenshots" to setOf("screenshot", "screenshots", "screencapture"),
                ).filter { (_, terms) -> words.any { it in terms } }
                topics.singleOrNull()?.first
            } else null
        val evidenceByHome = linkedMapOf<ProjectHomeCandidate, MutableList<FilingEvidence>>()
        fun add(home: ProjectHomeCandidate, kind: FilingEvidenceKind, detail: String, weight: Int) {
            evidenceByHome.getOrPut(home) { mutableListOf() } += FilingEvidence(kind, detail, weight)
        }

        correctionRules.forEach { rule ->
            if (ProjectEvidenceTerms.containsTerm(artifact.displayName, rule.term)) {
                val candidates = homes.matchingNamed(rule.destinationFolder)
                    .ifEmpty { listOf(syntheticHome(rule.destinationFolder, storageRoot)) }
                candidates.forEach { home ->
                    add(home, FilingEvidenceKind.USER_MAPPING, "learned mapping “${rule.term}” → ${rule.destinationFolder}", 120)
                }
            }
        }

        projectKeywords.forEach { keyword ->
            val filenameHit = ProjectEvidenceTerms.containsTerm(artifact.displayName, keyword.term)
            val contentHit = !filenameHit && ProjectEvidenceTerms.containsTerm(artifact.indexedText, keyword.term)
            val archiveHit = !filenameHit && artifact.archiveSample.any { ProjectEvidenceTerms.containsTerm(it, keyword.term) }
            if (filenameHit || contentHit || archiveHit) {
                val home = homes.bestNamed(keyword.projectFolder)
                    ?: syntheticHome(keyword.projectFolder, storageRoot)
                val weight = when {
                    filenameHit -> 105
                    archiveHit -> 82
                    else -> 74
                }
                val kind = when {
                    filenameHit -> FilingEvidenceKind.FILENAME
                    archiveHit -> FilingEvidenceKind.ARCHIVE_ENTRY
                    else -> FilingEvidenceKind.INDEXED_CONTENT
                }
                add(home, kind, "project mapping “${keyword.term}” → ${keyword.projectFolder}", weight)
            }
        }

        homes.forEach { home ->
            val inferredAlias = meaningfulTokens(home.name).joinToString(" ").takeIf { it.length >= 4 }
            val labels = (listOfNotNull(home.name, inferredAlias) + home.aliases)
                .filter { it.isNotBlank() }
                .distinctBy { it.lowercase(Locale.ROOT) }
            val filenameMatch = labels.maxOfOrNull { label -> textMatchScore(artifact.displayName, label) } ?: 0
            if (filenameMatch >= 65) {
                add(home, FilingEvidenceKind.PROJECT_HOME, "filename matches project home ${home.name}", filenameMatch + if (home.persisted) 10 else 0)
            }
            val labelMatch = artifact.apkLabel?.let { label -> textMatchScore(label, home.name) } ?: 0
            if (labelMatch >= 65) {
                add(home, FilingEvidenceKind.APK_LABEL, "APK label matches ${home.name}", labelMatch + 15)
            }
            val packageName = artifact.apkPackageName
            if (packageName != null && home.packageIds.any { it.equals(packageName, ignoreCase = true) }) {
                add(home, FilingEvidenceKind.APK_PACKAGE, "APK package $packageName is registered to ${home.name}", 140)
            }
            if (labels.any { label -> artifact.archiveSample.any { entry -> ProjectEvidenceTerms.containsTerm(entry, label) } }) {
                add(home, FilingEvidenceKind.ARCHIVE_ENTRY, "archive entries mention ${home.name}", 78)
            }
            if (artifact.indexedText.isNotBlank() && labels.any { ProjectEvidenceTerms.containsTerm(artifact.indexedText, it) }) {
                val heading = artifact.indexedText.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(160)
                val headingTokens = meaningfulTokens(heading).toSet()
                val titleMarker = heading.trimStart().startsWith("#") || headingMarker.containsMatchIn(heading)
                val identifiesTitle = titleMarker && labels.any { label ->
                    val tokens = meaningfulTokens(label).toSet()
                    tokens.isNotEmpty() && headingTokens.containsAll(tokens)
                }
                add(home, FilingEvidenceKind.INDEXED_CONTENT,
                    if (identifiesTitle) "document heading identifies ${home.name}" else "indexed document content mentions ${home.name}",
                    if (identifiesTitle) 94 else 70)
            }
        }

        explicitContentProject(artifact.indexedText)?.let { title ->
            val candidates = homes.matchingNamed(title).ifEmpty { listOf(syntheticHome(title, storageRoot)) }
            candidates.forEach { home ->
                add(home, FilingEvidenceKind.INDEXED_CONTENT, "document explicitly names project “$title”", 94)
            }
        }

        artifact.apkLabel?.takeIf { isUsefulLabel(it) }?.let { label ->
            val home = homes.bestNamed(label) ?: syntheticHome(label, storageRoot)
            add(home, FilingEvidenceKind.APK_LABEL, "APK metadata identifies “$label”", 112)
        }

        artifact.apkPackageName?.let { pkg ->
            val packageLeaf = pkg.substringAfterLast('.').takeIf { it.length >= 3 }
            if (packageLeaf != null) {
                homes.forEach { home ->
                    val score = textMatchScore(packageLeaf, home.name)
                    if (score >= 70) add(home, FilingEvidenceKind.APK_PACKAGE, "APK package name resembles ${home.name}", score)
                }
            }
        }

        guessedProjectLabel(artifact.displayName)?.let { guessed ->
            val repeated = (repeatedLabels[normalizeCompact(guessed)] ?: 0) >= 2
            val matchingHome = homes.bestNamed(guessed)
            if (matchingHome != null && textMatchScore(guessed, matchingHome.name) >= 65) {
                add(matchingHome, FilingEvidenceKind.FILENAME, "filename identifies ${matchingHome.name}", if (repeated) 92 else 78)
            } else if (repeated && imageTopic == null) {
                val synthetic = syntheticHome(guessed, storageRoot)
                add(synthetic, FilingEvidenceKind.FILENAME, "repeated filename family identifies $guessed", 84)
            }
        }

        val mapped = evidenceByHome.entries.filter { (_, evidence) -> evidence.any { it.kind == FilingEvidenceKind.USER_MAPPING } }
        // Remembered user intent takes priority; two remembered owners require an explicit choice.
        if (mapped.size > 1) {
            return FilingDecision(artifact, null, null, releaseOf(artifact), null, FilingConfidence.UNRESOLVED,
                mapped.flatMap { it.value.filter { evidence -> evidence.kind == FilingEvidenceKind.USER_MAPPING } } +
                    FilingEvidence(FilingEvidenceKind.PROJECT_AMBIGUITY, "Remembered mappings identify competing homes; choose a project home.", 200))
        }
        val ranked = mapped.ifEmpty { evidenceByHome.entries.toList() }
            .sortedByDescending { (_, evidence) -> evidence.sumOf { it.weight } }
        val best = ranked.firstOrNull()
        if (best == null) {
            NonProjectMediaFiling.propose(artifact, storageRoot)?.let { return it }
            if (imageTopic != null) {
                val topicHome = ProjectHomeCandidate(imageTopic, "${storageRoot.trimEnd('/')}/Images/$imageTopic", hierarchy = ProjectHierarchyStrategy.FLAT)
                return FilingDecision(
                    artifact = artifact,
                    projectName = imageTopic,
                    projectHome = topicHome,
                    release = null,
                    destinationDirectory = topicHome.path,
                    confidence = FilingConfidence.PROBABLE,
                    evidence = listOf(FilingEvidence(FilingEvidenceKind.FILENAME, "image filename suggests $imageTopic; confirm this topic", 70)),
                    createsProjectHome = true,
                )
            }
            return FilingDecision(
                artifact = artifact,
                projectName = null,
                projectHome = null,
                release = releaseOf(artifact),
                destinationDirectory = null,
                confidence = FilingConfidence.UNRESOLVED,
                evidence = emptyList(),
            )
        }

        val createsFolderHome = artifact.isDirectory && !storageRoot.startsWith("content://") &&
            homes.none { normalize(it.path) == normalize(best.key.path) }
        val home = if (createsFolderHome) best.key.copy(
            path = "${storageRoot.trimEnd('/')}/Documents/${sanitizeSegment(artifact.displayName) ?: error("Unsafe folder name")}",
        ) else best.key
        val evidence = best.value.distinctBy { it.kind to it.detail }
        val score = evidence.sumOf { it.weight }
        val runnerUp = ranked.getOrNull(1)
        val runnerUpScore = runnerUp?.value?.sumOf { it.weight } ?: 0
        if (runnerUp != null && runnerUpScore >= PROBABLE_SCORE && score - runnerUpScore < AMBIGUOUS_PROJECT_MARGIN) {
            return FilingDecision(
                artifact = artifact,
                projectName = null,
                projectHome = null,
                release = releaseOf(artifact),
                destinationDirectory = null,
                confidence = FilingConfidence.UNRESOLVED,
                evidence = evidence + FilingEvidence(
                    FilingEvidenceKind.PROJECT_AMBIGUITY,
                    "matches both ${home.name} and ${runnerUp.key.name}; choose a project home",
                    200,
                ),
            )
        }
        val release = releaseOf(artifact)
        val confidence = when {
            score >= STRONG_SCORE && (release != null || home.hierarchy != ProjectHierarchyStrategy.VERSIONED) -> FilingConfidence.STRONG
            score >= STRONG_SCORE -> FilingConfidence.PROBABLE
            score >= PROBABLE_SCORE -> FilingConfidence.PROBABLE
            else -> FilingConfidence.UNRESOLVED
        }

        return FilingDecision(
            artifact = artifact,
            projectName = home.name,
            projectHome = home,
            release = release,
            destinationDirectory = if (confidence == FilingConfidence.UNRESOLVED) null
                else if (createsFolderHome) home.path.substringBeforeLast('/')
                else destinationFor(home, release, artifact),
            confidence = confidence,
            evidence = evidence,
            createsProjectHome = !home.persisted && homes.none { normalize(it.path) == normalize(home.path) },
        )
    }

    fun releaseOf(artifact: FilingArtifact): String? {
        artifact.apkVersionName?.trim()?.takeIf { isUsefulVersion(it) }?.let { return normalizeVersion(it) }
        VERSION_REGEX.find(artifact.displayName)?.value?.let { return normalizeVersion(it) }
        artifact.archiveSample.asSequence()
            .mapNotNull { VERSION_REGEX.find(it)?.value }
            .firstOrNull()
            ?.let { return normalizeVersion(it) }
        return null
    }

    fun sanitizeSegment(value: String?): String? {
        val clean = value?.trim()?.trimEnd('.', ' ')?.take(80)?.trim() ?: return null
        if (clean.isBlank() || clean == "." || clean == "..") return null
        if ('/' in clean || '\\' in clean || clean.any { it.isISOControl() }) return null
        return clean
    }

    fun destinationFor(home: ProjectHomeCandidate, release: String?, artifact: FilingArtifact): String {
        val base = home.path.trimEnd('/')
        if (artifact.isDirectory) return base
        return when (home.hierarchy) {
            ProjectHierarchyStrategy.FLAT -> base
            ProjectHierarchyStrategy.VERSIONED -> sanitizeSegment(release)?.let { "$base/$it" } ?: base
            ProjectHierarchyStrategy.PROJECT_ROLES -> roleFor(artifact, release)?.let { role ->
                val folder = home.roleFolders[role] ?: role
                if (folder.isBlank()) base else "$base/$folder"
            } ?: base
            ProjectHierarchyStrategy.CATEGORY -> "$base/${categoryFor(artifact.extension)}"
        }
    }

    private fun categoryFor(extension: String): String = when (extension.lowercase(Locale.ROOT)) {
        "png", "jpg", "jpeg", "webp", "gif", "heic" -> "Images"
        "mp3", "m4a", "flac", "wav", "ogg" -> "Audio"
        "mp4", "mkv", "mov", "webm" -> "Video"
        "apk", "aab" -> "Apps"
        "zip", "7z", "rar", "tar", "gz" -> "Archives"
        else -> "Documents"
    }

    private fun roleFor(artifact: FilingArtifact, release: String?): String? {
        val name = artifact.displayName.lowercase(Locale.ROOT)
        val heading = artifact.indexedText.lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(160).lowercase(Locale.ROOT)
        val extension = artifact.extension.lowercase(Locale.ROOT)
        return when {
            manuscriptRole.containsMatchIn(name) -> "Manuscript"
            draftRole.containsMatchIn(name) -> "Drafts"
            notesRole.containsMatchIn(name) -> "Notes"
            manuscriptRole.containsMatchIn(heading) -> "Manuscript"
            draftRole.containsMatchIn(heading) -> "Drafts"
            notesRole.containsMatchIn(heading) -> "Notes"
            extension in setOf("png", "jpg", "jpeg", "webp", "gif", "heic") -> "Images"
            extension in setOf("zip", "7z", "rar", "tar", "gz") -> "Archive"
            release != null -> "Versions"
            else -> null
        }
    }

    private fun syntheticHome(name: String, storageRoot: String): ProjectHomeCandidate {
        val safe = sanitizeSegment(name) ?: "Unsorted project"
        val directStorage = !storageRoot.startsWith("content://")
        return ProjectHomeCandidate(
            name = safe,
            path = storageRoot.trimEnd('/') + if (directStorage) "/Documents/$safe" else "/$safe",
            aliases = listOf(safe),
            hierarchy = ProjectHierarchyStrategy.PROJECT_ROLES,
            persisted = false,
        )
    }

    /** Only a bounded explicit project field can introduce a home from content alone. */
    private fun explicitContentProject(text: String): String? {
        val labels = text.lineSequence().take(16).mapNotNull { line ->
            val title = explicitProjectField.matchEntire(line.take(160))?.groupValues?.get(1)?.trim()?.trim('"', '\'')
                ?: return@mapNotNull null
            title.takeIf { sanitizeSegment(it) == it && meaningfulTokens(it).isNotEmpty() }
        }.distinct().take(2).toList()
        return labels.singleOrNull()
    }

    private val explicitProjectField = Regex("(?i)\\s*(?:#{1,3}\\s*)?(?:project(?:\\s+title)?|series)\\s*[:—-]\\s*(.+?)\\s*")

    private fun List<ProjectHomeCandidate>.matchingNamed(label: String): List<ProjectHomeCandidate> {
        val scored = map { home -> home to (listOf(home.name) + home.aliases).maxOf { textMatchScore(label, it) } }
            .filter { it.second >= 62 }
        val best = scored.maxOfOrNull { it.second } ?: return emptyList()
        return scored.filter { it.second == best }.map { it.first }.distinctBy { normalize(it.path) }
    }

    private fun List<ProjectHomeCandidate>.bestNamed(label: String): ProjectHomeCandidate? =
        map { it to textMatchScore(label, it.name) }
            .filter { it.second >= 62 }
            .maxWithOrNull(compareBy<Pair<ProjectHomeCandidate, Int>> { it.second }.thenBy { if (it.first.persisted) 1 else 0 })
            ?.first

    private fun eventTime(artifact: FilingArtifact): Long? = artifact.createdAt ?: artifact.modifiedAt

    private fun closeInTime(a: Long?, b: Long?, windowMs: Long): Boolean =
        a != null && b != null && abs(a - b) <= windowMs

    private fun isSupportingArtifact(artifact: FilingArtifact): Boolean =
        artifact.extension.lowercase(Locale.ROOT) in SUPPORTING_EXTENSIONS &&
            guessedProjectLabel(artifact.displayName) == null

    private fun textMatchScore(a: String, b: String): Int {
        val ac = normalizeCompact(a)
        val bc = normalizeCompact(b)
        if (ac.isBlank() || bc.isBlank()) return 0
        if (ac == bc) return 100
        if (ac.contains(bc) || bc.contains(ac)) {
            val shorter = minOf(ac.length, bc.length)
            val longer = maxOf(ac.length, bc.length)
            return (72 + (28.0 * shorter / longer)).toInt().coerceAtMost(98)
        }
        val at = meaningfulTokens(a)
        val bt = meaningfulTokens(b)
        if (at.isEmpty() || bt.isEmpty()) return 0
        val intersection = at.intersect(bt).size
        if (intersection == 0) return 0
        val union = at.union(bt).size
        return (55 + 45.0 * intersection / union).toInt()
    }

    private fun guessedProjectLabel(filename: String): String? {
        val base = filename.substringBeforeLast('.', filename)
            .replace(VERSION_REGEX, " ")
            .replace(Regex("(?i)\\b(?:source|src|build|release|debug|signed|canonical|handoff|notes?|master|private|arm64|universal|apk|zip|bundle|dev\\d*)\\b"), " ")
            .replace(Regex("[_\\-.]+"), " ")
            .trim()
        val tokens = base.split(Regex("\\s+"))
            .filter { token ->
                token.length >= 2 &&
                    token.lowercase(Locale.ROOT) !in genericTokens &&
                    token.any(Char::isLetter)
            }
            .take(4)
        if (tokens.isEmpty()) return null
        val joined = tokens.joinToString(" ").trim()
        if (joined.length < 3) return null
        return joined.split(Regex("(?<=[a-z])(?=[A-Z])|\\s+"))
            .filter { it.isNotBlank() }
            .joinToString(" ") { token -> token.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() } }
    }

    private fun meaningfulTokens(value: String): Set<String> =
        value.replace(Regex("(?<=[a-z])(?=[A-Z])"), " ")
            .lowercase(Locale.ROOT)
            .split(Regex("[^a-z0-9]+"))
            .filter { it.length >= 2 && it !in genericTokens && !it.all(Char::isDigit) }
            .toSet()

    private fun normalize(value: String): String = value.trim().trimEnd('/').lowercase(Locale.ROOT)
    private fun normalizeCompact(value: String): String = value.lowercase(Locale.ROOT).filter(Char::isLetterOrDigit)
    private fun isUsefulLabel(value: String): Boolean = value.trim().length >= 3 && value.lowercase(Locale.ROOT) !in genericTokens
    private fun isUsefulVersion(value: String): Boolean = value.any(Char::isDigit) && value.length <= 40
    private fun normalizeVersion(value: String): String = value.trim().removePrefix("v").removePrefix("V").trim(' ', '-', '_')

    private val SUPPORTING_EXTENSIONS = setOf(
        "png", "jpg", "jpeg", "webp", "gif", "svg", "txt", "md", "json", "yaml", "yml",
    )

    private val VERSION_REGEX = Regex(
        "(?i)(?<![A-Za-z0-9])v?\\d+(?:\\.\\d+){1,3}(?:[-_](?:dev|alpha|beta|rc|hb)[A-Za-z0-9.-]*)?(?![A-Za-z0-9])",
    )
}
