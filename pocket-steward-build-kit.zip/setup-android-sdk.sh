#!/usr/bin/env bash
# One-shot Android build setup for Pocket Steward.
# Idempotent: safe to re-run. Takes ~2 minutes on a cold sandbox.
#
# Usage, from anywhere:
#   bash setup-android-sdk.sh [/path/to/pocket-steward]
#
# If a project path is given, local.properties is written there too.
set -euo pipefail

SDK_ROOT="${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
PROJECT_DIR="${1:-}"

# Versions pinned to what Pocket Steward actually compiles against.
# compileSdk/targetSdk 36 => platforms;android-36 and build-tools 36.x.
CMDLINE_TOOLS_URL="https://dl.google.com/android/repository/commandlinetools-linux-13114758_latest.zip"
CMDLINE_TOOLS_FALLBACK="https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip"
PACKAGES=("platform-tools" "platforms;android-36" "build-tools;36.1.0")

echo "==> SDK root: $SDK_ROOT"

# --- JDK check. AGP 8.13 needs 17+; this project builds clean on 21. ---
if ! command -v java >/dev/null 2>&1; then
  echo "ERROR: no java on PATH. Install a JDK 17 or newer first." >&2
  exit 1
fi
JAVA_MAJOR=$(java -version 2>&1 | head -1 | sed -E 's/.*version "([0-9]+).*/\1/')
if [ "${JAVA_MAJOR:-0}" -lt 17 ]; then
  echo "ERROR: JDK $JAVA_MAJOR found, need 17 or newer." >&2
  exit 1
fi
echo "==> JDK $JAVA_MAJOR OK"

# --- command line tools ---
SDKMANAGER="$SDK_ROOT/cmdline-tools/latest/bin/sdkmanager"
if [ ! -x "$SDKMANAGER" ]; then
  echo "==> installing command line tools"
  mkdir -p "$SDK_ROOT/cmdline-tools"
  TMP=$(mktemp -d)
  curl -sSL --max-time 300 -o "$TMP/cmdline.zip" "$CMDLINE_TOOLS_URL" \
    || curl -sSL --max-time 300 -o "$TMP/cmdline.zip" "$CMDLINE_TOOLS_FALLBACK"
  unzip -q -o "$TMP/cmdline.zip" -d "$SDK_ROOT/cmdline-tools"
  # the zip unpacks to cmdline-tools/; sdkmanager requires it be named "latest"
  if [ -d "$SDK_ROOT/cmdline-tools/cmdline-tools" ]; then
    rm -rf "$SDK_ROOT/cmdline-tools/latest"
    mv "$SDK_ROOT/cmdline-tools/cmdline-tools" "$SDK_ROOT/cmdline-tools/latest"
  fi
  rm -rf "$TMP"
else
  echo "==> command line tools already present"
fi

export ANDROID_HOME="$SDK_ROOT"
export ANDROID_SDK_ROOT="$SDK_ROOT"

# --- licenses (non-interactive) ---
echo "==> accepting licenses"
yes | "$SDKMANAGER" --licenses --sdk_root="$SDK_ROOT" >/dev/null 2>&1 || true

# --- packages ---
echo "==> installing: ${PACKAGES[*]}"
"$SDKMANAGER" --sdk_root="$SDK_ROOT" "${PACKAGES[@]}" >/dev/null

# --- local.properties ---
if [ -n "$PROJECT_DIR" ]; then
  if [ -d "$PROJECT_DIR" ]; then
    echo "sdk.dir=$SDK_ROOT" > "$PROJECT_DIR/local.properties"
    echo "==> wrote $PROJECT_DIR/local.properties"
  else
    echo "WARNING: $PROJECT_DIR is not a directory; skipped local.properties" >&2
  fi
fi

echo
echo "==> done"
echo "    export ANDROID_HOME=$SDK_ROOT"
echo "    export ANDROID_SDK_ROOT=$SDK_ROOT"
echo
echo "    cd <project> && ./gradlew clean assembleDebug testDebugUnitTest --stacktrace"
