#!/usr/bin/env bash
# Paste-and-run in the Claude Code sandbox. Answers one question:
# can this environment build an Android project at all?
echo "== JDK =="
java -version 2>&1 | head -1 || echo "NO JAVA"
echo
echo "== hosts an Android build needs =="
for url in \
  "https://dl.google.com/android/repository/repository2-3.xml" \
  "https://dl.google.com/dl/android/maven2/com/android/tools/build/gradle/8.13.2/gradle-8.13.2.pom" \
  "https://repo1.maven.org/maven2/org/jetbrains/kotlin/kotlin-gradle-plugin/2.3.20/kotlin-gradle-plugin-2.3.20.pom" \
  "https://plugins.gradle.org/m2/com/google/devtools/ksp/com.google.devtools.ksp.gradle.plugin/2.3.12/com.google.devtools.ksp.gradle.plugin-2.3.12.pom" \
  "https://services.gradle.org/distributions/gradle-8.13-bin.zip" ; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" --max-time 25 -L "$url" 2>/dev/null || echo "FAIL")
  printf "%-6s %s\n" "$code" "$(echo "$url" | cut -d/ -f3)"
done
echo
echo "200 or 30x on all five = this sandbox can build. Run setup-android-sdk.sh."
echo "403/407/000 on dl.google.com only = egress allowlist is the blocker."
