# Make Claude Code build Pocket Steward itself

Goal: Claude Code compiles and tests the app in its own sandbox, so the
source no longer has to be shuttled somewhere else to find out whether it
builds.

## Step 1 — find out whether it's actually blocked (30 seconds)

In the Claude Code sandbox:

```bash
bash check-android-build-access.sh
```

Five hosts, five status codes. **200 or 30x on all five means that sandbox can
build**, and everything after this is a two minute install. The Android SDK is
not special: it is just files served over HTTPS from `dl.google.com`.

This step exists because "can't reach dl.google.com" has been treated as a
fixed fact of that environment without anyone printing a status code. It may
be true. It may also be that one tool failed once, through a proxy, and the
conclusion stuck. The check settles it either way, and it costs nothing.

## Step 2 — if the check passes, install and build

```bash
bash setup-android-sdk.sh /path/to/pocket-steward
export ANDROID_HOME=$HOME/android-sdk
export ANDROID_SDK_ROOT=$HOME/android-sdk
cd /path/to/pocket-steward
./gradlew clean assembleDebug testDebugUnitTest --stacktrace
```

The script is idempotent, needs JDK 17 or newer, installs
`platform-tools`, `platforms;android-36` and `build-tools;36.1.0`, accepts
licenses non-interactively, and writes `local.properties` for you.

Verified end to end in this session: installed into an empty SDK root, then
built Milestone 3 to an APK with SHA-256 `d4efd2ed…fff0d9a5`, byte-identical
to the one built against the pre-existing SDK. So the script is not a
suggestion, it is the exact path that produced the shipped artifact.

## Step 3 — if the check fails only on dl.google.com

Then it is an egress allowlist, and no script fixes that. Three ways out, in
order of how much they actually help:

**Get the host allowed.** `dl.google.com` is where both the SDK packages and
every AndroidX artifact live. Without it there is no Android build. This is
the only fix that ends the problem permanently.

**Seed the sandbox offline.** Two archives cover it: the SDK pieces in use
(269 MB zipped) and Gradle's resolved dependency cache (361 MB zipped). Both
exist already and can be regenerated on request. They cannot travel through a
Claude chat, which caps attachments at 30 MiB, so they need a transfer path
that isn't this one.

**Keep the current split.** Authoring in one place, compiling in another. It
works, and it is what has been costing the round trips.

## Known traps, so they stop recurring

Full detail lives in `BUILD_ENVIRONMENT.md` in the project. The two that have
actually cost build cycles:

**Scope members are not importable.** Two consecutive rounds failed on this.
`item` belongs to `LazyListScope`; `weight` belongs to `ColumnScope` and
`RowScope`. Both are available implicitly inside the corresponding lambda and
neither has a public top-level declaration to import. `items`, `fillMaxWidth`,
`fillMaxSize` and `padding` genuinely are top-level, which is what makes the
mistake look reasonable. Adding an import for `item` or `weight` fails the
build every time, and the `weight` case fails with a confusing "it is
internal in file" rather than an unresolved reference.

**The Compose BOM has a ceiling.** While AGP is 8.13.2 and compileSdk is 36,
the BOM cannot go past 2026.06.01. Anything newer resolves Compose 1.12+,
which declares `minCompileSdk=37` and a minimum AGP of 9.1.0, and fails
`checkDebugAarMetadata` with 20+ issues. Moving up means moving AGP and
compileSdk in the same change.

## Files here

- `check-android-build-access.sh` — the diagnostic in step 1
- `setup-android-sdk.sh` — the installer in step 2
- this README
